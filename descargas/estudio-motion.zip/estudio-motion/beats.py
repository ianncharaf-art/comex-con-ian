#!/usr/bin/env python3
"""Mide el ritmo de una canción para que las animaciones caigan en los golpes.

Uso:  python3 beats.py tema.mp3            → escribe beats.json
Necesita: pip install numpy librosa soundfile

beats.json trae:
  bpm        tempo de la canción
  beats      cada golpe (segundos)
  downbeats  el primer golpe de cada compás (cada 4)
  hits       los golpes más fuertes (para el gancho, el número fuerte y el cierre)
"""
import json
import sys

import librosa
import numpy as np


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    y, sr = librosa.load(sys.argv[1], sr=None, mono=True)
    tempo, frames = librosa.beat.beat_track(y=y, sr=sr)
    beats = librosa.frames_to_time(frames, sr=sr)
    onset = librosa.onset.onset_strength(y=y, sr=sr)
    picos = librosa.onset.onset_detect(onset_envelope=onset, sr=sr)
    fuerza = onset[picos]
    top = picos[np.argsort(fuerza)[-12:]] if len(picos) else []
    data = {
        "bpm": round(float(np.atleast_1d(tempo)[0]), 1),
        "beats": [round(float(b), 3) for b in beats],
        "downbeats": [round(float(b), 3) for b in beats[::4]],
        "hits": sorted(round(float(t), 3) for t in librosa.frames_to_time(top, sr=sr)),
    }
    with open("beats.json", "w") as f:
        json.dump(data, f, indent=2)
    print(f"BPM {data['bpm']} · {len(data['beats'])} golpes · guardado en beats.json")


if __name__ == "__main__":
    main()
