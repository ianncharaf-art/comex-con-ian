---
name: comex-reel
description: Crea un reel animado de Comex con Ian a partir de una frase (tema, dato o plantilla A-E), lo renderiza en MP4 y lo revisa hasta que esté para publicar.
---

# comex-reel

Ian te pasa una frase, por ejemplo: "comex-reel: plantilla B, qué es FOB" o "comex-reel: noticia flash, sube el límite del courier a USD 3.000".

## Pasos

1. Leé `CLAUDE.md` (marca, prohibidos, contrato de render).
2. Elegí la plantilla:
   - A · Cuánto cuesta traerlo: base `escenas/zapatillas.html`.
   - B · Comex en 20 segundos: un concepto, tarjeta que se transforma en 3 pasos.
   - C · Noticia flash: titular, qué cambia, a quién le pega, desde cuándo, fuente.
   - D · Mito o verdad: la frase, el veredicto con golpe, la explicación en 2 pantallas.
   - E · El viaje de un producto: ruta fábrica → puerto → barco → aduana → local con el costo sumando.
3. Si hay datos (precios, aranceles, fechas), buscá la fuente oficial y anotala en un comentario de la escena. Si no hay fuente, preguntale a Ian.
4. Escribí el guion por escenas con los tiempos y mostráselo a Ian. Esperá su "dale".
5. Copiá la escena base a `escenas/<nombre>.html` y cambiá textos, datos, tiempos y `window.HITS`.
6. `node render.mjs escenas/<nombre>.html --fotos 1,4,8,12` → mirá las fotos y corregí.
7. `node render.mjs escenas/<nombre>.html` → `node revisar.mjs salida/<nombre>-9x16.mp4 --escena escenas/<nombre>.html`.
8. Mirá `salida/revision/hoja.png`, `celular.png` y `gancho.png`. Puntuá de 1 a 10 en gancho, legibilidad en celu, movimiento,
   variedad, composición, marca y sonido. Arreglá los 3 peores. Repetí hasta 8 o más en todo (máximo 4 vueltas).
9. Render final con `--todos` (y `--voz` si Ian pasó la voz). Escribí también el texto de la voz (máximo 45 palabras, rioplatense)
   y un caption con 3 a 5 hashtags.
10. Decile a Ian dónde quedaron los archivos y las notas que te pusiste.
