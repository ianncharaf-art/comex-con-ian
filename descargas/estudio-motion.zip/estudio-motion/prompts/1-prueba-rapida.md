# Prompt 1 · Prueba rápida (el "one-liner" del tweet)

Sirve para probar que el estudio anda. No para publicar: todos los que usan este prompt sacan videos parecidos.

```
Hacé un video de motion graphics de 15 segundos, dinámico, mostrando lo increíble que sos como motion designer.
Usá la marca de CLAUDE.md. Dale con todo.
```
