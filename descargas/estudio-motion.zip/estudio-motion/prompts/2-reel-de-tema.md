# Prompt 2 · Reel de un tema (el que vas a usar todos los días)

```
/comex-reel plantilla [A/B/C/D/E]: [TEMA]
Dato principal: [NÚMERO o FRASE] (fuente: [LINK])
Para: [Tomi que arranca / Graciela pyme]
Gancho: [la frase que choca, máximo 6 palabras]
```

Ejemplo:

```
/comex-reel plantilla B: qué es FOB
Dato principal: el 80% de los que arrancan compara precios FOB con precios de góndola
Para: Tomi que arranca
Gancho: "Ese precio en Alibaba es mentira"
```
