# Prompt 5 · Brief de director (videos largos o especiales)

Para un video de 45 a 90 segundos o algo importante (tu presentación, un lanzamiento). Usá esfuerzo máximo.

```
# [TÍTULO DEL VIDEO]

## La idea en una frase
[Ej: Un contenedor viaja de Shenzhen a Buenos Aires y en cada parada se suma un costo, hasta que el producto de USD 9 sale USD 70 en el local.]

## Referencias
[2 o 3 links o capturas y qué te gusta de cada uno]

## Herramientas y presupuesto
Render con render.mjs. Sin APIs pagas salvo [ElevenLabs para la voz]. Sé económico.

## Personajes y elementos
[Ej: el muñequito de Ian (marca-personal/carruseles/muñequito-ian.svg), el contenedor dorado, el barco azul]

## Guion por escenas
1. [0-3 s] ...
2. [3-8 s] ...
...

## Texto en pantalla
Máximo 8 palabras por pantalla. Números en Space Mono.

## Etapas (esperá mi "dale" en cada una)
plan → fotos de cada escena → animatic (video sin pulir) → video completo → pulido → render final.

## Revisión
Después de cada render corré revisar.mjs, poné nota de 1 a 10 en gancho, legibilidad, movimiento, variedad,
composición, marca y sonido, y arreglá los 3 peores. Seguí hasta tener 8 en todo.

## Entregas
salida/[nombre]-9x16.mp4, 1x1 y 16x9 + texto de la voz + caption.
```
