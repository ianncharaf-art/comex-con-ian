# Prompt 4 · Tarjeta que se transforma (UI morph del tweet)

Un solo elemento que cambia de forma sin cortes. Ideal para explicar pasos (cómo se arma un costo, los pasos de una importación).

```
<video>
  <formato>9x16, 1080x1920, 16 segundos, 120 BPM (8 compases)</formato>
  <tema>[TEMA, por ejemplo: los 5 pasos para importar por courier]</tema>
  <estados>
    1 (0-2 s): [estado inicial: una tarjeta con la pregunta]
    2 (2-5 s): [la tarjeta se estira y muestra el paso 1]
    3 (5-8 s): [se da vuelta y muestra el paso 2]
    4 (8-11 s): [se divide en dos columnas: paso 3 y 4]
    5 (11-14 s): [vuelve a una sola con el resultado]
    6 (14-16 s): [cierre, y el último cuadro igual al primero para que haga loop]
  </estados>
  <reglas>
    Un solo contenedor que se transforma, nunca cortes.
    Un cursor que hace clic dispara cada cambio (con sonido click).
    Resortes 'normal' para la tarjeta y 'duro' para el texto.
    Cada cambio cae en el primer golpe de un compás.
  </reglas>
  <cuidado>
    El texto no puede salirse de la tarjeta en ningún formato.
    El primer cuadro ya muestra algo (es la portada).
  </cuidado>
</video>
```
