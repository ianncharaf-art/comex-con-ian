# Prompt 6 · Editar tus videos hablando a cámara

1. Grabá tu video y exportalo de CapCut sin subtítulos (`mi-video.mp4`).
2. En CapCut generá los subtítulos automáticos y exportalos como `.srt` (o pedile a Claude Code: "transcribí mi-video.mp4 con Whisper y guardá mi-video.srt").
3. Si querés carteles con datos, armá un `carteles.json` como el de `ejemplos/`.
4. Corré:

```
node render.mjs escenas/capa-tu-video.html --base mi-video.mp4 --srt mi-video.srt --datos carteles.json
```

O pedíselo a Claude Code:

```
Editá mi-video.mp4: subtítulos palabra por palabra con la marca, mi cartel de nombre al principio,
y un cartel con el dato cada vez que digo un número. Buscá los números en el .srt, armá carteles.json y renderizá.
Revisá con revisar.mjs que los subtítulos no tapen mi cara.
```
