# Prompt 3 · Copiar el estilo de un video que te gusta

1. Bajá el video de referencia y ponelo en `referencias/ref.mp4`.
2. Pegale esto a Claude Code:

```
Sacá 1 cuadro por segundo de referencias/ref.mp4 con ffmpeg y miralos.
Escribí referencias/guia-estilo.md con: ritmo (cuánto dura cada pantalla), tipo de transiciones,
tamaño y peso de las letras, cómo entra cada elemento y qué movimiento de cámara usa.
Copiá la gramática, no el contenido ni los colores: lo adaptás a la marca de CLAUDE.md.
Después escribí referencias/lista-de-tomas.md para un video sobre [TEMA] con ese estilo.
No programes nada hasta que te diga "dale".
```
