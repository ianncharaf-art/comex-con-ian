# Estudio de motion · Comex con Ian

Este es el estudio de videos animados de Ian (@iancharaf7), 18 años, Argentina, tercera generación de importadores.
Habla de comercio exterior para gente que arranca (Tomi, 21) y pymes (Graciela, 45). Escribí todo en español rioplatense.

## Cómo funciona (contrato de render)

- Cada video es un archivo HTML en `escenas/` que importa `lib/marca.css` y `lib/motion.js`.
- La escena define `window.DURATION` (segundos), `window.BPM` (opcional), `window.HITS` (golpes de sonido) y `window.seek(t)`.
- `seek(t)` dibuja el cuadro exacto para el segundo `t`. Tiene que ser una función pura del tiempo:
  nada de `setTimeout`, `requestAnimationFrame`, animaciones CSS, transiciones CSS ni `Math.random()` sin semilla (usar `M.rand(semilla)`).
- Movimiento con `M.resorte(t, inicio, 'duro'|'normal'|'juguete')`. Para un valor que cambia varias veces, `M.resortes(t, [[t0,v0],[t1,v1]...])`.
- Render: `node render.mjs escenas/x.html` → `salida/x-9x16.mp4`. Con `--todos` saca 9x16, 1x1 y 16x9.
- Las escenas usan `M.formato` / `[data-formato]` para reacomodar el texto en cada formato, nunca para recortar.
- Para capas encima de un video de Ian: `<div id="stage" class="transparente">` y render con `--base video.mp4`.

## Marca

- Fondo negro #050608. Dorado #D4AF37 para lo importante. Azul #3D7BFF para etiquetas y datos. Blanco hueso #F4F1EA para texto.
- Letras: Anton (títulos, en mayúsculas), Archivo (texto), Space Mono (números y etiquetas).
- Cierre de 2 a 3 segundos: "IAN · @iancharaf7".
- Vertical 1080x1920. Lo importante entre el 10% y el 75% de la altura (abajo y a la derecha lo tapan los botones de TikTok).

## Estructura de un reel (15 a 25 s)

1. Gancho (0 a 2 s): un número o una frase que choca. El primer cuadro ya tiene que mostrar algo.
2. El tema (2 a 3 s).
3. Tres momentos (2 a 4 s cada uno). Mejor una sola tarjeta que se transforma que cortes.
4. Un número fuerte (3 s).
5. Cierre con nombre y usuario.

## Prohibido

- Título centrado sobre un degradado.
- Que todo aparezca con el mismo fundido suave.
- Etiquetas chiquitas en las esquinas.
- Más de 8 palabras por pantalla.
- Banderas, mapas o íconos de relleno que no aporten al dato.
- Pantallas de más de 4 segundos sin movimiento.
- Inventar datos. Cada número de comex tiene que salir de una fuente o de un cálculo explicado en un comentario de la escena.

## Sonido

- Efectos sintetizados en `window.HITS` (`click`, `pop`, `whoosh`, `thump`, `ding`), uno en cada cambio importante.
- `window.BPM` genera una base musical simple. Si Ian pasa una canción, medir el ritmo con `python3 beats.py tema.mp3` y poner los golpes en los tiempos de `beats.json`.
- Voz: `--voz voz.mp3` (CapCut o ElevenLabs). Todo se normaliza a -14 LUFS.

## Forma de trabajo (siempre en este orden)

1. Plan: escribir el guion por escenas (texto en pantalla + tiempos) y esperar el "dale" de Ian.
2. Fotos: `node render.mjs escenas/x.html --fotos 1,4,8,12` y mirar las imágenes.
3. Video: render completo.
4. Revisión: `node revisar.mjs salida/x-9x16.mp4 --escena escenas/x.html`. Mirar `salida/revision/hoja.png`, `celular.png` y `gancho.png`.
   Puntuar de 1 a 10: gancho, se lee en el celu, movimiento, variedad, composición, marca, sonido sincronizado.
   Arreglar los 3 peores y repetir hasta 8 o más en todo.
5. Entregar los tres formatos con `--todos`.

## Esfuerzo

- Arreglos chicos: esfuerzo medio.
- Un video nuevo: esfuerzo alto.
- Un video de lanzamiento o algo que tiene que explotar: esfuerzo máximo.
