#!/usr/bin/env node
// Motor de render del estudio.
// Abre una escena HTML en Chromium, le pide cada cuadro con window.seek(t), saca una captura
// y ffmpeg arma el MP4. Después suma los efectos de sonido, tu voz y la música.
//
// Ejemplos:
//   node render.mjs escenas/zapatillas.html
//   node render.mjs escenas/zapatillas.html --formato 1x1
//   node render.mjs escenas/zapatillas.html --todos            (9x16, 1x1 y 16x9)
//   node render.mjs escenas/zapatillas.html --fotos 1,4,8,12   (capturas para aprobar)
//   node render.mjs escenas/capa-subtitulos.html --base mi-video.mp4 --srt mi-video.srt
//   node render.mjs escenas/zapatillas.html --voz voz.mp3 --musica tema.mp3
import { chromium } from 'playwright';
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { sintetizar, guardarWav } from './lib/sfx.mjs';

const TAMANOS = { '9x16': [1080, 1920], '1x1': [1080, 1080], '16x9': [1920, 1080] };

function leerArgs(argv) {
  const a = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const s = argv[i];
    if (s.startsWith('--')) {
      const k = s.slice(2), v = argv[i + 1];
      if (v === undefined || v.startsWith('--')) a[k] = true; else { a[k] = v; i++; }
    } else a._.push(s);
  }
  return a;
}

function srtAJson(texto) {
  const aSeg = s => { const [h, m, r] = s.trim().replace(',', '.').split(':'); return +h * 3600 + +m * 60 + +r; };
  return texto.replace(/\r/g, '').split(/\n\n+/).map(b => {
    const l = b.trim().split('\n');
    const i = l.findIndex(x => x.includes('-->'));
    if (i < 0) return null;
    const [a, z] = l[i].split('-->');
    return { inicio: aSeg(a), fin: aSeg(z), texto: l.slice(i + 1).join(' ').trim() };
  }).filter(Boolean);
}

function info(ruta) {
  const r = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration:stream=codec_type', '-of', 'json', ruta], { encoding: 'utf8' });
  const j = JSON.parse(r.stdout || '{}');
  return { dur: parseFloat(j.format?.duration || 0), audio: (j.streams || []).some(s => s.codec_type === 'audio') };
}

function ffmpeg(args) {
  const r = spawnSync('ffmpeg', ['-y', '-v', 'error', ...args], { stdio: 'inherit' });
  if (r.status !== 0) throw new Error('ffmpeg falló: ' + args.join(' '));
}

async function abrir(browser, escena, formato, opts) {
  const [W, H] = TAMANOS[formato];
  const page = await browser.newPage({ viewport: { width: W, height: H }, deviceScaleFactor: 1 });
  page.on('pageerror', e => console.error('Error en la escena:', e.message));
  if (opts.data) await page.addInitScript(d => { window.DATA = d; }, opts.data);
  const url = pathToFileURL(path.resolve(escena)).href + '?f=' + formato + (opts.capa ? '&capa=1' : '');
  await page.goto(url);
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate(() => window.ready || null);
  const esc = await page.evaluate(() => ({ dur: window.DURATION, hits: window.HITS || [], bpm: window.BPM || 0, ok: typeof window.seek === 'function' }));
  if (!esc.ok) throw new Error('La escena no tiene window.seek(t).');
  return { page, W, H, ...esc };
}

async function fotos(browser, escena, formato, tiempos, opts) {
  const { page } = await abrir(browser, escena, formato, opts);
  const nombre = path.basename(escena, '.html');
  for (const t of tiempos) {
    await page.evaluate(t => window.seek(t), t);
    const out = path.join('salida', `${nombre}-${formato}-t${t}.png`);
    await page.screenshot({ path: out, omitBackground: !!opts.capa });
    console.log('Foto:', out);
  }
  await page.close();
}

async function renderVideo(browser, escena, formato, a, opts) {
  const fps = +(a.fps || 30), sub = +(a.blur || 1);
  const base = a.base ? info(a.base) : null;
  const { page, W, H, dur: durEsc, hits, bpm } = await abrir(browser, escena, formato, opts);
  const dur = +(a.dur || durEsc || base?.dur || 0);
  if (!dur) throw new Error('No sé cuánto dura: poné window.DURATION en la escena o usá --dur.');
  const nombre = a.salida || path.join('salida', `${path.basename(escena, '.html')}-${formato}.mp4`);
  const tmp = nombre.replace(/\.mp4$/, '.tmp.mp4');
  const alfa = !!opts.capa;

  // Paso 1: cuadros → video (sin sonido).
  const entrada = ['-f', 'image2pipe', '-framerate', String(fps * sub), '-c:v', alfa ? 'png' : 'mjpeg', '-i', '-'];
  let filtro = sub > 1 ? `[0:v]tmix=frames=${sub},framestep=${sub}[fg]` : '[0:v]null[fg]';
  const args = [...entrada];
  if (base) {
    args.push('-i', a.base);
    filtro += `;[1:v]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},fps=${fps},setsar=1[bg];[bg][fg]overlay=0:0:shortest=1[v]`;
  } else filtro += `;[fg]fps=${fps},setsar=1[v]`;
  args.push('-filter_complex', filtro, '-map', '[v]', '-t', String(dur),
    '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '16', '-preset', 'medium', '-movflags', '+faststart', tmp);
  const ff = spawn('ffmpeg', ['-y', '-v', 'error', ...args], { stdio: ['pipe', 'inherit', 'inherit'] });
  const fin = new Promise((ok, mal) => ff.on('close', c => (c === 0 ? ok() : mal(new Error('ffmpeg falló')))));

  const total = Math.ceil(dur * fps * sub);
  const t0 = Date.now();
  for (let i = 0; i < total; i++) {
    const t = i / (fps * sub);
    await page.evaluate(t => window.seek(t), t);
    const img = await page.screenshot(alfa ? { type: 'png', omitBackground: true } : { type: 'jpeg', quality: 95 });
    if (!ff.stdin.write(img)) await new Promise(r => ff.stdin.once('drain', r));
    if (i % (fps * sub) === 0) process.stdout.write(`\r${formato}: ${Math.round((i / total) * 100)}%  `);
  }
  ff.stdin.end();
  await fin;
  await page.close();
  process.stdout.write(`\r${formato}: 100% (${((Date.now() - t0) / 1000).toFixed(0)} s)\n`);

  // Paso 2: sonido. Efectos sintetizados + audio del video base + voz + música, a -14 LUFS.
  const pistas = [], filtros = [];
  const extra = [];
  if (hits.length || bpm) {
    const wav = nombre.replace(/\.mp4$/, '.sfx.wav');
    guardarWav(wav, sintetizar({ hits, dur, bpm: a['sin-musica'] ? 0 : bpm }));
    extra.push('-i', wav); pistas.push('sfx');
  }
  if (base?.audio) { extra.push('-i', a.base); pistas.push('base'); }
  if (a.voz) { extra.push('-i', a.voz); pistas.push('voz'); }
  if (a.musica) { extra.push('-stream_loop', '-1', '-i', a.musica); pistas.push('musica'); }

  if (!pistas.length) { fs.renameSync(tmp, nombre); console.log('Listo:', nombre); return nombre; }
  const hayVoz = pistas.includes('voz') || pistas.includes('base');
  const vol = { sfx: hayVoz ? 0.55 : 0.9, base: 1, voz: 1, musica: hayVoz ? 0.18 : 0.6 };
  const partes = pistas.map((p, k) => `[${k + 1}:a]aresample=48000,volume=${vol[p]}[a${k}]`);
  const mezcla = pistas.map((_, k) => `[a${k}]`).join('') +
    `amix=inputs=${pistas.length}:normalize=0:duration=longest,atrim=0:${dur},loudnorm=I=-14:TP=-1.5:LRA=11[a]`;
  filtros.push(...partes, mezcla);
  ffmpeg(['-i', tmp, ...extra, '-filter_complex', filtros.join(';'), '-map', '0:v', '-map', '[a]',
    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-t', String(dur), '-movflags', '+faststart', nombre]);
  fs.unlinkSync(tmp);
  fs.rmSync(nombre.replace(/\.mp4$/, '.sfx.wav'), { force: true });
  console.log('Listo:', nombre);
  return nombre;
}

async function main() {
  const a = leerArgs(process.argv.slice(2));
  const escena = a._[0];
  if (!escena) {
    console.log('Uso: node render.mjs escenas/mi-escena.html [--formato 9x16|1x1|16x9] [--todos] [--fotos 1,3,6]\n' +
      '      [--base mi-video.mp4] [--srt subtitulos.srt] [--datos datos.json] [--voz voz.mp3] [--musica tema.mp3]\n' +
      '      [--fps 30] [--blur 4] [--dur 15] [--salida salida/x.mp4] [--sin-musica]');
    process.exit(1);
  }
  fs.mkdirSync('salida', { recursive: true });
  const data = {};
  if (a.srt) data.subs = srtAJson(fs.readFileSync(a.srt, 'utf8'));
  if (a.datos) Object.assign(data, JSON.parse(fs.readFileSync(a.datos, 'utf8')));
  const opts = { data: Object.keys(data).length ? data : null, capa: !!a.base || !!a.capa };
  const formatos = a.todos ? Object.keys(TAMANOS) : [a.formato || '9x16'];

  const browser = await chromium.launch();
  try {
    for (const f of formatos) {
      if (!TAMANOS[f]) throw new Error('Formato desconocido: ' + f);
      if (a.fotos) await fotos(browser, escena, f, String(a.fotos).split(',').map(Number), opts);
      else await renderVideo(browser, escena, f, { ...a, salida: formatos.length > 1 ? undefined : a.salida }, opts);
    }
  } finally {
    await browser.close();
  }
}

main().catch(e => { console.error('\n' + e.message); process.exit(1); });
