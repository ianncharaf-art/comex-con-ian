#!/usr/bin/env node
// Revisión de un video terminado: lo que Claude (o vos) mira antes de publicar.
//   node revisar.mjs salida/zapatillas-9x16.mp4
//   node revisar.mjs salida/zapatillas-9x16.mp4 --escena escenas/zapatillas.html   (también chequea que cada render salga igual)
// Genera en salida/revision/:
//   hoja.png       12 cuadros repartidos en todo el video (para ver el ritmo de un vistazo)
//   celular.png    los mismos cuadros a 360 px de ancho (¿se lee en un celu?)
//   costura.png    primer y último cuadro lado a lado (para videos en loop)
//   gancho.png     6 cuadros del primer segundo y medio (el gancho tiene que pegar sin audio)
// e imprime el volumen (LUFS) y la duración.
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const [video, ...resto] = process.argv.slice(2);
if (!video) { console.log('Uso: node revisar.mjs salida/mi-video.mp4 [--escena escenas/mi-escena.html]'); process.exit(1); }
const dir = path.join(path.dirname(video), 'revision');
fs.mkdirSync(dir, { recursive: true });

const run = (cmd, args) => spawnSync(cmd, args, { encoding: 'utf8' });
const ff = args => { const r = run('ffmpeg', ['-y', '-v', 'error', ...args]); if (r.status) console.error(r.stderr); };
const dur = parseFloat(run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', video]).stdout);

const n = 12, paso = dur / n;
ff(['-i', video, '-vf', `fps=1/${paso.toFixed(3)},scale=270:-1,tile=6x2:padding=6:color=0x222222`, '-frames:v', '1', path.join(dir, 'hoja.png')]);
ff(['-i', video, '-vf', `fps=1/${paso.toFixed(3)},scale=360:-1,scale=180:-1,tile=6x2:padding=4`, '-frames:v', '1', path.join(dir, 'celular.png')]);
ff(['-i', video, '-t', '1.5', '-vf', 'fps=4,scale=270:-1,tile=6x1:padding=6:color=0x222222', '-frames:v', '1', path.join(dir, 'gancho.png')]);
ff(['-i', video, '-sseof', '-0.05', '-i', video, '-filter_complex', '[0:v]trim=end_frame=1,scale=360:-1[a];[1:v]trim=end_frame=1,scale=360:-1[b];[a][b]hstack', '-frames:v', '1', path.join(dir, 'costura.png')]);

const lufs = run('ffmpeg', ['-hide_banner', '-i', video, '-af', 'ebur128', '-f', 'null', '-']).stderr.match(/I:\s+(-?[\d.]+) LUFS\s*\n\s*Threshold/g);
const integrado = lufs ? lufs[lufs.length - 1].match(/-?[\d.]+/)[0] : 'sin audio';

console.log(`Duración: ${dur.toFixed(2)} s`);
console.log(`Volumen: ${integrado} LUFS (ideal para redes: -14; entre -16 y -13 está bien)`);
console.log(`Revisión guardada en ${dir}/ (hoja, celular, gancho, costura)`);

const i = resto.indexOf('--escena');
if (i >= 0) {
  // Mismo cuadro dos veces → tiene que dar exactamente la misma imagen.
  const { chromium } = await import('playwright');
  const { pathToFileURL } = await import('node:url');
  const b = await chromium.launch();
  const hashes = [];
  for (let k = 0; k < 2; k++) {
    const p = await b.newPage({ viewport: { width: 1080, height: 1920 } });
    await p.goto(pathToFileURL(path.resolve(resto[i + 1])).href + '?f=9x16');
    await p.evaluate(() => document.fonts.ready);
    await p.evaluate(t => window.seek(t), dur * 0.37);
    hashes.push(crypto.createHash('md5').update(await p.screenshot()).digest('hex'));
    await p.close();
  }
  await b.close();
  console.log(hashes[0] === hashes[1] ? 'Determinismo: OK (el mismo cuadro sale idéntico)' : 'Determinismo: FALLA (hay algo aleatorio o con timer en la escena)');
}

console.log(`
Ahora puntuá del 1 al 10 (o pedile a Claude que lo haga mirando las imágenes):
  gancho · se lee en el celu · movimiento · variedad · composición · marca · sonido sincronizado
Arreglá los 3 peores y volvé a renderizar hasta tener 8 o más en todo.`);
