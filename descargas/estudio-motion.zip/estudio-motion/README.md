# Estudio de motion · Comex con Ian

Tu fábrica de videos animados. Claude escribe una escena en HTML, el motor la dibuja cuadro por cuadro y sale un MP4 con sonido.

## Instalar (una sola vez)

1. Instalá [Node.js 22](https://nodejs.org) y [ffmpeg](https://ffmpeg.org/download.html) (en Mac: `brew install node ffmpeg`).
2. Abrí la terminal en esta carpeta y corré: `npm run instalar`
3. Probá: `npm run ejemplo` → aparece `salida/zapatillas-9x16.mp4`.

Más fácil: abrí Claude Code en esta carpeta y decile "instalá todo lo que necesita el estudio y renderizá el ejemplo".

## Comandos

| Querés | Comando |
| --- | --- |
| Fotos para aprobar antes de animar | `node render.mjs escenas/zapatillas.html --fotos 1,4,8,12` |
| Video vertical | `node render.mjs escenas/zapatillas.html` |
| Los 3 formatos (9x16, 1x1, 16x9) | `node render.mjs escenas/zapatillas.html --todos` |
| Con tu voz y música | `... --voz voz.mp3 --musica tema.mp3` |
| Más suave (motion blur) | `... --blur 4` (tarda 4 veces más) |
| Editar tu video hablando | `node render.mjs escenas/capa-tu-video.html --base mi-video.mp4 --srt mi-video.srt --datos carteles.json` |
| Revisar antes de publicar | `node revisar.mjs salida/zapatillas-9x16.mp4 --escena escenas/zapatillas.html` |
| Medir el ritmo de una canción | `python3 beats.py tema.mp3` |
| Video nuevo con una frase (en Claude Code) | `/comex-reel plantilla B: qué es FOB` |

## Qué hay en cada carpeta

- `CLAUDE.md`: las reglas de la casa. Claude Code las lee siempre.
- `escenas/`: cada video es un HTML. `zapatillas.html` (plantilla A) y `capa-tu-video.html` (para tus videos).
- `lib/`: marca (colores y letras), resortes y sintetizador de sonidos.
- `prompts/`: los 6 prompts para copiar y pegar.
- `.claude/skills/comex-reel/`: el skill que convierte una frase en un video terminado.
- `salida/`: donde aparecen los videos.

Fuentes Anton, Archivo y Space Mono: licencia SIL Open Font License.
